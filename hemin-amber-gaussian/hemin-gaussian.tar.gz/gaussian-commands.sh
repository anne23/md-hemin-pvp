g16 < HEM_small_opt.com > HEM_small_opt.log

g16 < HEM_small_fc.com > HEM_small_fc.log

formchk HEM_small_opt.chk HEM_small_opt.fchk

g16 < HEM_large_mk.com > HEM_large_mk.log
